### 写在前面：你说不想用服务每次接入都要另外安装服务、你说扫码sdk初始化不方便限制太多、你说更新服务无法继续扫码、你说扫码不能暂停接收数据……一个扫码工具岂是如此不便之物？你们的声音我们听到啦！所以所以船新版本的扫码工具又双叕来了。*新版本的SDK使用更加灵活，新的扫码SDK初始化更加快速、更加稳定、内存、包体积、功耗、CPU占用率进一步下降*。新版本的SDK为3.3+。使用扫码SDK一步到位，所有的功能都打进AAR包让你们使用毫无压力。

### 1、开发包说说明

- **scan-sdk-v3.3.0-release.aar**扫码SDK依赖**telpo_sdk.jar**包，所以接入时需要将两个包一同放进项目


### 2、接入

1. 集成sdk

2. 初始化

3. 实现扫码结果回调

4. 释放

   ### 详情，请参考 sample 代码接入

### 3、SDK API 详情

1. **回调方法**

   ```Java
       /**
        * 扫码回调
        *
        * @param data 条码数据
        */
       void onScanCallBack(String data);
   
   
       /**
        * 扫码回调
        *
        * @param pBytes 条码的byte数组数据
        */
       default void onScanCallBack(byte[] pBytes) {
       }
   
       /**
        * 串口初始化结果回调，该回调默认实现，开发者
        * 可以根据需求自己实现
        *
        * @param isSuccess 初始化结果。
        *                  true表示初始化成功，
        *                  false表示初始化失败
        */
       default void onInitScan(boolean isSuccess) {
       }
   ```

3. **普通方法**

   ```Java
       /**
        * 初始化串口
        *
        * @param pContext   上下文对象
        * @param pPath      串口地址
        * @param pSBaudRate 波特率
        */
       void initSerial(Context pContext, String pPath, int pSBaudRate);
   
       /**
        * 初始化串口
        *
        * @param pContext      上下文对象
        * @param pPath         串口地址
        * @param pSBaudRate    波特率
        * @param pScanCallBack 扫码回调
        */
       void initSerial(Context pContext, String pPath, int pSBaudRate, ScanCallBack pScanCallBack);
   
       /**
        * 设置回调，通过设置回调实现暂停、继续接收数据功能
        *
        * @param pScanCallBack 扫码回调接口
        */
       void setScanCallBack(ScanCallBack pScanCallBack);
   
   
       /**
        * 播放声音
        *
        * @param play true播放声音，false不播放声音
        */
       void playSound(boolean play);
   
       /**
        * 释放
        */
       void release();
   ```
   
   
   
   
   
   
   
   
